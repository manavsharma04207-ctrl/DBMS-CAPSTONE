"""
Phase 5: Integrated Payroll & Attendance Management System (Role-Based Web UI + CLI)
- Zero external dependencies (uses Python stdlib sqlite3 + http.server).
- Enforces Phase 1 3NF schema, Phase 2 triggers & payroll calculations, Phase 3 reports/indexes, and Phase 4 RBAC & ACID transactions.
"""
import os
import sys
import math
import uuid
import sqlite3
import urllib.parse
from http.cookies import SimpleCookie
from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import datetime, date, timedelta

DB_PATH = os.path.join(os.path.dirname(__file__), "payroll_capstone.db")
SESSIONS = {}


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def calculate_monthly_tax(gross_monthly: float) -> float:
    """Equivalent to Phase 2 PostgreSQL fn_calculate_monthly_tax(NUMERIC)."""
    if gross_monthly < 0:
        raise ValueError(f"Invalid gross salary: {gross_monthly} cannot be negative")
    annual = gross_monthly * 12.0
    if annual <= 400000:
        tax = 0.0
    elif annual <= 800000:
        tax = (annual - 400000) * 0.05
    elif annual <= 1200000:
        tax = 20000 + (annual - 800000) * 0.10
    elif annual <= 1600000:
        tax = 60000 + (annual - 1200000) * 0.15
    else:
        tax = 120000 + (annual - 1600000) * 0.20
    return round(tax / 12.0, 2)


def generate_monthly_payroll(conn, emp_id: int, month: int, year: int, working_days: int = 22):
    """Equivalent to Phase 2 PostgreSQL sp_generate_monthly_payroll wrapped in an ACID transaction."""
    struct = conn.execute(
        "SELECT basic_pay, hra, special_allowance, pf_contribution FROM salary_structures WHERE emp_id = ?",
        (emp_id,)
    ).fetchone()
    if not struct:
        raise ValueError(f"Salary structure not configured for emp_id={emp_id}")

    gross = float(struct["basic_pay"]) + float(struct["hra"]) + float(struct["special_allowance"])
    pf = float(struct["pf_contribution"])

    logs = conn.execute(
        """SELECT status FROM attendance_logs
           WHERE emp_id = ? AND strftime('%m', att_date) = ? AND strftime('%Y', att_date) = ?""",
        (emp_id, f"{month:02d}", str(year))
    ).fetchall()

    present_days = 0.0
    late_count = 0
    unpaid_days = 0.0
    for r in logs:
        st = r["status"]
        if st in ("PRESENT", "LATE"):
            present_days += 1.0
        elif st == "HALF_DAY":
            present_days += 0.5
        elif st == "ABSENT":
            unpaid_days += 1.0
        if st == "LATE":
            late_count += 1

    late_pen_days = math.floor(late_count / 3) * 0.5
    per_day = round(gross / working_days, 2)
    lop_deduction = round((unpaid_days + late_pen_days) * per_day, 2)
    taxable = max(gross - lop_deduction, 0.0)
    tax = calculate_monthly_tax(taxable)
    net_pay = max(round(taxable - tax - pf, 2), 0.0)

    conn.execute(
        """INSERT INTO payroll_runs (
               emp_id, pay_month, pay_year, working_days, present_days,
               unpaid_leave_days, late_penalty_days, gross_earnings,
               tax_deduction, pf_deduction, lop_deduction, net_pay, payment_status
           ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PROCESSED')
           ON CONFLICT(emp_id, pay_month, pay_year) DO UPDATE SET
               working_days=excluded.working_days,
               present_days=excluded.present_days,
               unpaid_leave_days=excluded.unpaid_leave_days,
               late_penalty_days=excluded.late_penalty_days,
               gross_earnings=excluded.gross_earnings,
               tax_deduction=excluded.tax_deduction,
               pf_deduction=excluded.pf_deduction,
               lop_deduction=excluded.lop_deduction,
               net_pay=excluded.net_pay,
               processed_at=CURRENT_TIMESTAMP""",
        (emp_id, month, year, working_days, present_days, unpaid_days,
         late_pen_days, gross, tax, pf, lop_deduction, net_pay)
    )


def init_db():
    """Initializes the Phase 1 3NF schema, Phase 2 triggers, Phase 3 indexes, and 3-month seed data."""
    if os.path.exists(DB_PATH):
        return
    conn = get_db()
    with conn:
        conn.executescript("""
        CREATE TABLE departments (
            dept_id     INTEGER PRIMARY KEY AUTOINCREMENT,
            dept_name   TEXT NOT NULL UNIQUE,
            cost_center TEXT NOT NULL UNIQUE,
            location    TEXT NOT NULL DEFAULT 'Gurugram HQ'
        );

        CREATE TABLE designations (
            desig_id           INTEGER PRIMARY KEY AUTOINCREMENT,
            title              TEXT NOT NULL UNIQUE,
            grade_level        TEXT NOT NULL,
            standard_shift_hrs REAL NOT NULL DEFAULT 8.0 CHECK (standard_shift_hrs > 0)
        );

        CREATE TABLE employees (
            emp_id        INTEGER PRIMARY KEY AUTOINCREMENT,
            emp_code      TEXT NOT NULL UNIQUE,
            full_name     TEXT NOT NULL,
            email         TEXT NOT NULL UNIQUE,
            dept_id       INTEGER NOT NULL REFERENCES departments(dept_id),
            desig_id      INTEGER NOT NULL REFERENCES designations(desig_id),
            join_date     TEXT NOT NULL,
            status        TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'INACTIVE', 'ON_NOTICE')),
            system_role   TEXT NOT NULL DEFAULT 'EMPLOYEE' CHECK (system_role IN ('HR_ADMIN', 'EMPLOYEE')),
            password_hash TEXT NOT NULL
        );

        CREATE TABLE salary_structures (
            struct_id         INTEGER PRIMARY KEY AUTOINCREMENT,
            emp_id            INTEGER NOT NULL UNIQUE REFERENCES employees(emp_id) ON DELETE CASCADE,
            basic_pay         REAL NOT NULL CHECK (basic_pay > 0),
            hra               REAL NOT NULL DEFAULT 0 CHECK (hra >= 0),
            special_allowance REAL NOT NULL DEFAULT 0 CHECK (special_allowance >= 0),
            pf_contribution   REAL NOT NULL DEFAULT 0 CHECK (pf_contribution >= 0),
            effective_from    TEXT NOT NULL
        );

        CREATE TABLE leave_types (
            leave_type_id INTEGER PRIMARY KEY AUTOINCREMENT,
            type_code     TEXT NOT NULL UNIQUE,
            type_name     TEXT NOT NULL,
            is_paid       INTEGER NOT NULL DEFAULT 1,
            annual_quota  INTEGER NOT NULL CHECK (annual_quota >= 0)
        );

        CREATE TABLE leave_requests (
            leave_id      INTEGER PRIMARY KEY AUTOINCREMENT,
            emp_id        INTEGER NOT NULL REFERENCES employees(emp_id) ON DELETE CASCADE,
            leave_type_id INTEGER NOT NULL REFERENCES leave_types(leave_type_id),
            start_date    TEXT NOT NULL,
            end_date      TEXT NOT NULL,
            total_days    INTEGER NOT NULL CHECK (total_days > 0),
            status        TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED')),
            reason        TEXT,
            applied_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CHECK (end_date >= start_date)
        );

        CREATE TABLE attendance_logs (
            att_id       INTEGER PRIMARY KEY AUTOINCREMENT,
            emp_id       INTEGER NOT NULL REFERENCES employees(emp_id) ON DELETE CASCADE,
            att_date     TEXT NOT NULL,
            check_in     TEXT,
            check_out    TEXT,
            status       TEXT NOT NULL CHECK (status IN ('PRESENT', 'LATE', 'HALF_DAY', 'ABSENT', 'ON_LEAVE')),
            late_minutes INTEGER NOT NULL DEFAULT 0 CHECK (late_minutes >= 0),
            remarks      TEXT,
            UNIQUE(emp_id, att_date),
            CHECK (check_out IS NULL OR check_in IS NULL OR check_out >= check_in)
        );

        CREATE TABLE payroll_runs (
            payroll_id        INTEGER PRIMARY KEY AUTOINCREMENT,
            emp_id            INTEGER NOT NULL REFERENCES employees(emp_id),
            pay_month         INTEGER NOT NULL CHECK (pay_month BETWEEN 1 AND 12),
            pay_year          INTEGER NOT NULL CHECK (pay_year >= 2020),
            working_days      INTEGER NOT NULL CHECK (working_days > 0),
            present_days      REAL NOT NULL CHECK (present_days >= 0),
            unpaid_leave_days REAL NOT NULL DEFAULT 0 CHECK (unpaid_leave_days >= 0),
            late_penalty_days REAL NOT NULL DEFAULT 0 CHECK (late_penalty_days >= 0),
            gross_earnings    REAL NOT NULL CHECK (gross_earnings >= 0),
            tax_deduction     REAL NOT NULL CHECK (tax_deduction >= 0),
            pf_deduction      REAL NOT NULL CHECK (pf_deduction >= 0),
            lop_deduction     REAL NOT NULL DEFAULT 0 CHECK (lop_deduction >= 0),
            net_pay           REAL NOT NULL CHECK (net_pay >= 0),
            payment_status    TEXT NOT NULL DEFAULT 'PROCESSED' CHECK (payment_status IN ('DRAFT', 'PROCESSED', 'PAID')),
            processed_at      TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(emp_id, pay_month, pay_year)
        );

        CREATE TABLE audit_logs (
            audit_id     INTEGER PRIMARY KEY AUTOINCREMENT,
            actor_user   TEXT NOT NULL,
            action_type  TEXT NOT NULL,
            target_table TEXT NOT NULL,
            target_id    INTEGER,
            details      TEXT,
            created_at   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        -- Phase 2 Trigger 1: Reject Overlapping Leaves
        CREATE TRIGGER trg_prevent_leave_overlap
        BEFORE INSERT ON leave_requests
        BEGIN
            SELECT RAISE(ABORT, 'Leave overlap error: Active/approved leave already exists in selected range')
            WHERE EXISTS (
                SELECT 1 FROM leave_requests
                WHERE emp_id = NEW.emp_id
                  AND status IN ('PENDING', 'APPROVED')
                  AND start_date <= NEW.end_date
                  AND end_date >= NEW.start_date
            );
        END;

        -- Phase 2 Trigger 2: Reject Attendance on Approved Leave
        CREATE TRIGGER trg_validate_attendance
        BEFORE INSERT ON attendance_logs
        BEGIN
            SELECT RAISE(ABORT, 'Attendance conflict: Employee has an APPROVED leave on this date')
            WHERE NEW.status IN ('PRESENT', 'LATE', 'HALF_DAY')
              AND EXISTS (
                  SELECT 1 FROM leave_requests
                  WHERE emp_id = NEW.emp_id
                    AND status = 'APPROVED'
                    AND NEW.att_date BETWEEN start_date AND end_date
              );
        END;

        -- Phase 3 Indexes
        CREATE INDEX idx_att_status_date_emp ON attendance_logs (status, att_date, emp_id);
        CREATE INDEX idx_payroll_period_emp  ON payroll_runs (pay_year, pay_month, emp_id);
        CREATE INDEX idx_emp_dept_id         ON employees (dept_id);
        """)

        conn.executemany(
            "INSERT INTO departments (dept_name, cost_center, location) VALUES (?, ?, ?)",
            [
                ("Engineering & AI", "CC-ENG-01", "Gurugram HQ"),
                ("Cloud & DevOps", "CC-OPS-02", "Gurugram HQ"),
                ("Product & Design", "CC-PRD-03", "Bengaluru Hub"),
                ("Human Resources", "CC-HRM-04", "Gurugram HQ"),
            ],
        )
        conn.executemany(
            "INSERT INTO designations (title, grade_level, standard_shift_hrs) VALUES (?, ?, ?)",
            [
                ("HR Manager", "L4", 8.0),
                ("Senior Software Engineer", "L4", 8.5),
                ("AI/ML Engineer", "L3", 8.5),
                ("DevOps Specialist", "L3", 8.5),
                ("Product Analyst", "L2", 8.0),
                ("Junior Backend Developer", "L1", 8.0),
            ],
        )
        emps = [
            ("EMP001", "Ananya Verma", "ananya.verma@techcorp.in", 4, 1, "2023-02-15", "ACTIVE", "HR_ADMIN", "admin123"),
            ("EMP002", "Tanish Sharma", "tanish.sharma@techcorp.in", 1, 3, "2024-06-01", "ACTIVE", "EMPLOYEE", "emp123"),
            ("EMP003", "Rohan Malhotra", "rohan.malhotra@techcorp.in", 1, 2, "2022-11-10", "ACTIVE", "EMPLOYEE", "emp123"),
            ("EMP004", "Priya Nair", "priya.nair@techcorp.in", 2, 4, "2023-08-21", "ACTIVE", "EMPLOYEE", "emp123"),
            ("EMP005", "Kabir Mehta", "kabir.mehta@techcorp.in", 3, 5, "2024-01-15", "ACTIVE", "EMPLOYEE", "emp123"),
            ("EMP006", "Sneha Iyer", "sneha.iyer@techcorp.in", 1, 2, "2022-04-04", "ACTIVE", "EMPLOYEE", "emp123"),
            ("EMP007", "Vikramaditya Rao", "vikram.rao@techcorp.in", 2, 4, "2023-09-12", "ACTIVE", "EMPLOYEE", "emp123"),
            ("EMP008", "Meera Krishnan", "meera.krishnan@techcorp.in", 1, 3, "2024-03-18", "ACTIVE", "EMPLOYEE", "emp123"),
            ("EMP009", "Aditya Kulkarni", "aditya.kulkarni@techcorp.in", 1, 6, "2025-07-01", "ACTIVE", "EMPLOYEE", "emp123"),
            ("EMP010", "Neha Gupta", "neha.gupta@techcorp.in", 3, 5, "2024-05-20", "ACTIVE", "EMPLOYEE", "emp123"),
            ("EMP011", "Siddharth Joshi", "siddharth.joshi@techcorp.in", 2, 6, "2025-07-15", "ACTIVE", "EMPLOYEE", "emp123"),
            ("EMP012", "Kavya Deshmukh", "kavya.deshmukh@techcorp.in", 4, 1, "2023-06-11", "ACTIVE", "HR_ADMIN", "admin123"),
        ]
        conn.executemany(
            """INSERT INTO employees (emp_code, full_name, email, dept_id, desig_id, join_date, status, system_role, password_hash)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            emps,
        )
        salaries = [
            (1, 65000, 26000, 19000, 3600, "2026-04-01"),
            (2, 55000, 22000, 18000, 3200, "2026-04-01"),
            (3, 75000, 30000, 25000, 4200, "2026-04-01"),
            (4, 58000, 23200, 16800, 3400, "2026-04-01"),
            (5, 45000, 18000, 12000, 2600, "2026-04-01"),
            (6, 78000, 31200, 25800, 4400, "2026-04-01"),
            (7, 60000, 24000, 16000, 3500, "2026-04-01"),
            (8, 52000, 20800, 15200, 3000, "2026-04-01"),
            (9, 35000, 14000, 9000, 2100, "2026-04-01"),
            (10, 46000, 18400, 13600, 2700, "2026-04-01"),
            (11, 34000, 13600, 8400, 2000, "2026-04-01"),
            (12, 62000, 24800, 18200, 3500, "2026-04-01"),
        ]
        conn.executemany(
            """INSERT INTO salary_structures (emp_id, basic_pay, hra, special_allowance, pf_contribution, effective_from)
               VALUES (?, ?, ?, ?, ?, ?)""",
            salaries,
        )
        conn.executemany(
            "INSERT INTO leave_types (type_code, type_name, is_paid, annual_quota) VALUES (?, ?, ?, ?)",
            [
                ("CL", "Casual Leave", 1, 12),
                ("SL", "Sick Leave", 1, 10),
                ("PL", "Privilege Leave", 1, 18),
                ("LWP", "Leave Without Pay", 0, 30),
            ],
        )
        conn.executemany(
            """INSERT INTO leave_requests (emp_id, leave_type_id, start_date, end_date, total_days, status, reason)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            [
                (2, 1, "2026-08-14", "2026-08-14", 1, "APPROVED", "Personal family errand"),
                (3, 2, "2026-09-10", "2026-09-11", 2, "APPROVED", "Viral fever recovery"),
                (5, 3, "2026-10-05", "2026-10-07", 3, "APPROVED", "Planned annual vacation"),
                (9, 1, "2026-10-20", "2026-10-21", 2, "PENDING", "Festival travel"),
            ],
        )

        # Seed 3 months (Aug-Oct 2026) attendance
        cur_date = date(2026, 8, 1)
        end_date = date(2026, 10, 31)
        approved_leaves = {
            (2, "2026-08-14"),
            (3, "2026-09-10"), (3, "2026-09-11"),
            (5, "2026-10-05"), (5, "2026-10-06"), (5, "2026-10-07"),
        }
        while cur_date <= end_date:
            if cur_date.weekday() < 5:
                d_str = cur_date.isoformat()
                for e in range(1, 13):
                    if (e, d_str) in approved_leaves:
                        conn.execute(
                            "INSERT INTO attendance_logs (emp_id, att_date, status, late_minutes, remarks) VALUES (?, ?, 'ON_LEAVE', 0, 'Approved Leave')",
                            (e, d_str),
                        )
                    elif (e == 9 and d_str in ("2026-08-19", "2026-09-22")) or (e == 11 and d_str == "2026-10-14"):
                        conn.execute(
                            "INSERT INTO attendance_logs (emp_id, att_date, status, late_minutes, remarks) VALUES (?, ?, 'ABSENT', 0, 'Uninformed absence')",
                            (e, d_str),
                        )
                    elif (e + cur_date.day) % 7 == 0:
                        mins = 28 + (e % 4) * 6
                        h = 9 + (30 + mins) // 60
                        m = (30 + mins) % 60
                        conn.execute(
                            "INSERT INTO attendance_logs (emp_id, att_date, check_in, check_out, status, late_minutes, remarks) VALUES (?, ?, ?, '18:30:00', 'LATE', ?, 'Traffic delay')",
                            (e, d_str, f"{h:02d}:{m:02d}:00", mins),
                        )
                    else:
                        m = 18 + (e % 5) * 4
                        conn.execute(
                            "INSERT INTO attendance_logs (emp_id, att_date, check_in, check_out, status, late_minutes, remarks) VALUES (?, ?, ?, '18:15:00', 'PRESENT', 0, 'Regular shift')",
                            (e, d_str, f"09:{m:02d}:00"),
                        )
            cur_date += timedelta(days=1)

        for m, w_days in [(8, 21), (9, 22), (10, 22)]:
            for e in range(1, 13):
                generate_monthly_payroll(conn, e, m, 2026, w_days)
    conn.close()


def handle_rbac_post_salary(user_session: dict, emp_id: int, new_basic: float, month: int = 10):
    """Application-layer RBAC + ACID Transaction handler for salary updates."""
    if not user_session or user_session.get("role") != "HR_ADMIN":
        return 403, "Unauthorized Access (403): HR_ADMIN privileges required."
    conn = get_db()
    try:
        with conn:
            conn.execute(
                "UPDATE salary_structures SET basic_pay = ?, hra = ROUND(? * 0.4, 2) WHERE emp_id = ?",
                (new_basic, new_basic, emp_id),
            )
            generate_monthly_payroll(conn, emp_id, month, 2026, 22)
            conn.execute(
                "INSERT INTO audit_logs (actor_user, action_type, target_table, target_id, details) VALUES (?, 'SALARY_UPDATE', 'salary_structures', ?, ?)",
                (user_session["emp_code"], emp_id, f"Updated basic_pay to {new_basic}"),
            )
        return 200, "Transaction COMMITTED: Salary structure & payslip updated."
    except Exception as exc:
        return 400, f"Transaction ROLLED BACK: {exc}"
    finally:
        conn.close()


class PayrollWebHandler(BaseHTTPRequestHandler):
    def get_session(self):
        cookie_hdr = self.headers.get("Cookie", "")
        cookie = SimpleCookie()
        cookie.load(cookie_hdr)
        sid = cookie["sid"].value if "sid" in cookie else None
        return SESSIONS.get(sid)

    def send_html(self, html: str, status: int = 200, set_cookie: str = None):
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        if set_cookie:
            self.send_header("Set-Cookie", set_cookie)
        self.end_headers()
        self.wfile.write(html.encode("utf-8"))

    def redirect(self, location: str, set_cookie: str = None):
        self.send_response(302)
        self.send_header("Location", location)
        if set_cookie:
            self.send_header("Set-Cookie", set_cookie)
        self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(parsed.query)
        sess = self.get_session()

        if parsed.path == "/logout":
            self.redirect("/login", "sid=; Path=/; Max-Age=0")
            return

        if parsed.path == "/login" or not sess:
            msg = qs.get("msg", [""])[0]
            alert = f"<div style='color:#b91c1c;margin-bottom:10px;'>{msg}</div>" if msg else ""
            html = f"""<!doctype html><html><head><title>TechCorp Payroll Login</title>
            <style>body{{font-family:system-ui;background:#f1f5f9;display:flex;justify-content:center;padding-top:70px;}}
            .card{{background:#fff;padding:28px;border-radius:10px;box-shadow:0 4px 16px rgba(0,0,0,.08);width:360px;}}
            input,button{{width:100%;padding:10px;margin:8px 0;box-sizing:border-box;border-radius:6px;border:1px solid #cbd5e1;}}
            button{{background:#1e3a8a;color:#fff;font-weight:600;border:none;cursor:pointer;}}</style></head>
            <body><div class='card'><h2>TechCorp DBMS Login</h2>{alert}
            <form method='post' action='/login'>
              <input name='emp_code' placeholder='EMP001 (HR) or EMP002 (Employee)' required>
              <input type='password' name='password' placeholder='admin123 or emp123' required>
              <button type='submit'>Sign In</button>
            </form>
            <p style='font-size:12px;color:#475569;'>HR Admin: <b>EMP001</b> / <code>admin123</code><br>Employee: <b>EMP002</b> / <code>emp123</code></p>
            </div></body></html>"""
            self.send_html(html)
            return

        month = int(qs.get("month", ["10"])[0])
        msg = qs.get("msg", [""])[0]
        conn = get_db()
        is_hr = sess["role"] == "HR_ADMIN"
        where_sql = "WHERE p.pay_year = 2026 AND p.pay_month = ?" + ("" if is_hr else " AND p.emp_id = ?")
        params = [f"{month:02d}", month] + ([] if is_hr else [sess["emp_id"]])

        rows = conn.execute(
            f"""SELECT e.emp_code, e.full_name, d.dept_name, p.*,
                       (SELECT COUNT(*) FROM attendance_logs a WHERE a.emp_id=e.emp_id AND a.status='LATE'
                        AND strftime('%m', a.att_date)=? AND strftime('%Y', a.att_date)='2026') AS late_count
                FROM payroll_runs p
                JOIN employees e ON p.emp_id = e.emp_id
                JOIN departments d ON e.dept_id = d.dept_id
                {where_sql} ORDER BY e.emp_code""",
            params,
        ).fetchall()
        emps = conn.execute("SELECT emp_id, emp_code, full_name FROM employees ORDER BY emp_code").fetchall() if is_hr else []
        conn.close()

        tr_html = "".join(
            f"<tr><td>{r['emp_code']}</td><td>{r['full_name']}</td><td>{r['dept_name']}</td>"
            f"<td>{r['present_days']}</td><td>{r['late_count']}</td><td>{r['unpaid_leave_days']}</td>"
            f"<td>{r['gross_earnings']:.2f}</td><td>{r['lop_deduction']:.2f}</td>"
            f"<td>{r['pf_deduction']:.2f}</td><td>{r['tax_deduction']:.2f}</td>"
            f"<td><b>{r['net_pay']:.2f}</b></td></tr>"
            for r in rows
        )
        hr_panel = ""
        if is_hr:
            opts = "".join(f"<option value='{e['emp_id']}'>{e['emp_code']} - {e['full_name']}</option>" for e in emps)
            hr_panel = f"""
            <div style='background:#fff;padding:16px;border-radius:8px;margin-bottom:20px;border:1px solid #e2e8f0;'>
              <h3>HR Admin: Transactional Salary Revision & Payroll Recalculation</h3>
              <form method='post' action='/salary' style='display:flex;gap:10px;'>
                <select name='emp_id'>{opts}</select>
                <input type='number' step='0.01' name='basic_pay' placeholder='New Basic Pay' required>
                <input type='hidden' name='month' value='{month}'>
                <button type='submit'>Commit & Recalculate</button>
              </form>
            </div>"""

        banner = f"<div style='padding:10px;background:#fef3c7;border:1px solid #f59e0b;margin-bottom:15px;'>{msg}</div>" if msg else ""
        html = f"""<!doctype html><html><head><title>Payroll & Attendance Dashboard</title>
        <style>body{{font-family:system-ui;background:#f8fafc;margin:0;}}
        .nav{{background:#0f172a;color:#fff;padding:14px 28px;display:flex;justify-content:space-between;}}
        .wrap{{max-width:1100px;margin:24px auto;padding:0 16px;}}
        table{{width:100%;border-collapse:collapse;background:#fff;}}
        th,td{{padding:9px 10px;border:1px solid #cbd5e1;font-size:13px;text-align:left;}}
        th{{background:#1e293b;color:#fff;}}</style></head>
        <body><div class='nav'><b>TechCorp Payroll & Attendance DBMS</b>
        <div>[{sess['role']}] {sess['full_name']} ({sess['emp_code']}) | <a href='/logout' style='color:#93c5fd;'>Logout</a></div></div>
        <div class='wrap'>{banner}{hr_panel}
        <h3>Monthly Attendance & Salary Slip Report (Month: {month}/2026)</h3>
        <table><thead><tr><th>Code</th><th>Name</th><th>Dept</th><th>Present</th><th>Late</th><th>Absent</th>
        <th>Gross</th><th>LOP</th><th>PF</th><th>Tax</th><th>Net Pay</th></tr></thead>
        <tbody>{tr_html}</tbody></table></div></body></html>"""
        self.send_html(html)

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length).decode("utf-8")
        form = urllib.parse.parse_qs(body)

        if self.path == "/login":
            code = form.get("emp_code", [""])[0].strip().upper()
            pwd = form.get("password", [""])[0].strip()
            conn = get_db()
            user = conn.execute("SELECT * FROM employees WHERE emp_code=? AND password_hash=?", (code, pwd)).fetchone()
            conn.close()
            if user:
                sid = str(uuid.uuid4())
                SESSIONS[sid] = dict(user)
                SESSIONS[sid]["role"] = user["system_role"]
                self.redirect("/", f"sid={sid}; Path=/; HttpOnly")
            else:
                self.redirect("/login?msg=Invalid+credentials")
            return

        if self.path == "/salary":
            sess = self.get_session()
            emp_id = int(form.get("emp_id", ["0"])[0])
            basic = float(form.get("basic_pay", ["0"])[0])
            month = int(form.get("month", ["10"])[0])
            _, status_msg = handle_rbac_post_salary(sess, emp_id, basic, month)
            self.redirect(f"/?month={month}&msg={urllib.parse.quote(status_msg)}")


def run_cli_report():
    init_db()
    conn = get_db()
    print("=== OCTOBER 2026 PAYROLL & ATTENDANCE SUMMARY (ALL 12 EMPLOYEES) ===")
    rows = conn.execute("""
        SELECT e.emp_code, e.full_name, d.dept_name, p.present_days,
               (SELECT COUNT(*) FROM attendance_logs a WHERE a.emp_id=e.emp_id AND a.status='LATE' AND strftime('%m',a.att_date)='10') AS late_cnt,
               p.unpaid_leave_days, p.gross_earnings, p.lop_deduction, p.pf_deduction, p.tax_deduction, p.net_pay
        FROM payroll_runs p
        JOIN employees e ON p.emp_id = e.emp_id
        JOIN departments d ON e.dept_id = d.dept_id
        WHERE p.pay_year = 2026 AND p.pay_month = 10
        ORDER BY e.emp_code
    """).fetchall()
    for r in rows:
        print(f"{r['emp_code']} | {r['full_name']:<17} | {r['dept_name']:<16} | Pres:{r['present_days']:>4.1f} | Late:{r['late_cnt']} | Gross:{r['gross_earnings']:>9.2f} | LOP:{r['lop_deduction']:>7.2f} | Tax:{r['tax_deduction']:>7.2f} | Net:{r['net_pay']:>9.2f}")
    conn.close()


if __name__ == "__main__":
    init_db()
    if "--cli" in sys.argv:
        run_cli_report()
    else:
        server = HTTPServer(("127.0.0.1", 5000), PayrollWebHandler)
        print("Running Payroll & Attendance Web UI at http://127.0.0.1:5000 (Ctrl+C to stop)")
        server.serve_forever()
