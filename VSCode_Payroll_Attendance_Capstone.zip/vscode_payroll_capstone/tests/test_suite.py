"""
Phase 4 Automated Verification & Security Test Suite
Executes valid, invalid, boundary, RBAC, and transaction rollback tests against the live database engine.
"""
import os
import sqlite3
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "app")))
import app as payroll_app


def run_all_tests():
    if os.path.exists(payroll_app.DB_PATH):
        os.remove(payroll_app.DB_PATH)
    payroll_app.init_db()

    results = []
    conn = payroll_app.get_db()

    # Test 1: Valid Attendance Entry
    try:
        with conn:
            conn.execute(
                "INSERT INTO attendance_logs (emp_id, att_date, check_in, check_out, status, late_minutes) VALUES (2, '2026-11-02', '09:20:00', '18:10:00', 'PRESENT', 0)"
            )
        results.append(("TC-01 Valid Attendance Insert", "PASS", "Inserted PRESENT log for EMP002 on 2026-11-02"))
    except Exception as e:
        results.append(("TC-01 Valid Attendance Insert", "FAIL", str(e)))

    # Test 2: Negative Salary Rejection + Transaction Rollback
    try:
        with conn:
            conn.execute("UPDATE salary_structures SET basic_pay = -5000 WHERE emp_id = 2")
        results.append(("TC-02 Negative Salary Constraint", "FAIL", "Allowed negative basic_pay"))
    except sqlite3.IntegrityError as e:
        results.append(("TC-02 Negative Salary Constraint", "PASS", f"Blocked & Rolled Back: {e}"))

    # Test 3: Duplicate Attendance Entry Rejection
    try:
        with conn:
            conn.execute(
                "INSERT INTO attendance_logs (emp_id, att_date, check_in, check_out, status) VALUES (2, '2026-11-02', '09:25:00', '18:00:00', 'PRESENT')"
            )
        results.append(("TC-03 Duplicate Attendance Entry", "FAIL", "Allowed duplicate punch-in"))
    except sqlite3.IntegrityError as e:
        results.append(("TC-03 Duplicate Attendance Entry", "PASS", f"Blocked duplicate (emp_id, att_date): {e}"))

    # Test 4: Overlapping Approved/Pending Leave Rejection (Trigger)
    try:
        with conn:
            conn.execute(
                "INSERT INTO leave_requests (emp_id, leave_type_id, start_date, end_date, total_days, status) VALUES (2, 1, '2026-08-14', '2026-08-15', 2, 'PENDING')"
            )
        results.append(("TC-04 Overlapping Leave Trigger", "FAIL", "Allowed overlapping leave"))
    except sqlite3.IntegrityError as e:
        results.append(("TC-04 Overlapping Leave Trigger", "PASS", f"Trigger blocked overlap: {e}"))

    # Test 5: Attendance Punch-In During Approved Leave (Trigger)
    try:
        with conn:
            conn.execute(
                "INSERT INTO attendance_logs (emp_id, att_date, check_in, status) VALUES (3, '2026-09-10', '09:20:00', 'PRESENT')"
            )
        results.append(("TC-05 Attendance on Approved Leave", "FAIL", "Allowed attendance during approved leave"))
    except sqlite3.IntegrityError as e:
        results.append(("TC-05 Attendance on Approved Leave", "PASS", f"Trigger blocked punch-in on approved leave: {e}"))

    # Test 6: RBAC Unauthorized Access Check (Employee calling HR salary update)
    emp_session = {"emp_id": 2, "emp_code": "EMP002", "full_name": "Tanish Sharma", "role": "EMPLOYEE"}
    code, msg = payroll_app.handle_rbac_post_salary(emp_session, 2, 999999.0, 10)
    if code == 403:
        results.append(("TC-06 RBAC Unauthorized Salary Edit", "PASS", f"Blocked EMPLOYEE role -> HTTP {code}: {msg}"))
    else:
        results.append(("TC-06 RBAC Unauthorized Salary Edit", "FAIL", f"Unexpected code {code}"))

    # Test 7: Boundary LOP Cap (Net Pay floors safely at 0.00 when LOP > Gross)
    with conn:
        conn.execute("UPDATE salary_structures SET basic_pay = 1000, hra = 0, special_allowance = 0, pf_contribution = 500 WHERE emp_id = 11")
        payroll_app.generate_monthly_payroll(conn, 11, 10, 2026, 22)
    row = conn.execute("SELECT net_pay FROM payroll_runs WHERE emp_id = 11 AND pay_month = 10").fetchone()
    if row and row["net_pay"] >= 0:
        results.append(("TC-07 Boundary Net Pay Floor", "PASS", f"Net pay safely floored at {row['net_pay']:.2f}"))
    else:
        results.append(("TC-07 Boundary Net Pay Floor", "FAIL", "Negative net pay underflow"))

    conn.close()
    for name, status, detail in results:
        print(f"[{status}] {name}: {detail}")


if __name__ == "__main__":
    run_all_tests()
