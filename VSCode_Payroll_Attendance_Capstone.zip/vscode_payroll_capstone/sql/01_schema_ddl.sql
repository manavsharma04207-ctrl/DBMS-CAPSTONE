-- ============================================================================
-- PHASE 1: RELATIONAL SCHEMA DESIGN (3NF NORMALIZED)
-- Theme: Employee Payroll & Attendance Management System (Mid-Sized IT Firm)
-- DBMS: PostgreSQL 15+ (Compatible with MySQL 8+ with minor syntax notes)
-- Note: This schema is the immutable foundation for Phases 2 through 5.
-- ============================================================================

DROP SCHEMA IF EXISTS payroll_mgmt CASCADE;
CREATE SCHEMA payroll_mgmt;
SET search_path TO payroll_mgmt;

-- 1. DEPARTMENTS (3NF: Department details separated from Employee to eliminate transitive dependency)
CREATE TABLE departments (
    dept_id         SERIAL PRIMARY KEY,
    dept_name       VARCHAR(80) NOT NULL UNIQUE,
    cost_center     VARCHAR(20) NOT NULL UNIQUE,
    location        VARCHAR(80) NOT NULL DEFAULT 'Gurugram HQ'
);

-- 2. DESIGNATIONS / ROLES (3NF: Role grade & standard shift hours separated)
CREATE TABLE designations (
    desig_id            SERIAL PRIMARY KEY,
    title               VARCHAR(80) NOT NULL UNIQUE,
    grade_level         VARCHAR(10) NOT NULL,
    standard_shift_hrs  NUMERIC(4,2) NOT NULL DEFAULT 8.00 CHECK (standard_shift_hrs > 0)
);

-- 3. EMPLOYEES (Core Master Entity)
CREATE TABLE employees (
    emp_id          SERIAL PRIMARY KEY,
    emp_code        VARCHAR(15) NOT NULL UNIQUE,
    full_name       VARCHAR(100) NOT NULL,
    email           VARCHAR(120) NOT NULL UNIQUE,
    dept_id         INT NOT NULL REFERENCES departments(dept_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    desig_id        INT NOT NULL REFERENCES designations(desig_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    join_date       DATE NOT NULL,
    status          VARCHAR(20) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'INACTIVE', 'ON_NOTICE')),
    system_role     VARCHAR(20) NOT NULL DEFAULT 'EMPLOYEE' CHECK (system_role IN ('HR_ADMIN', 'EMPLOYEE')),
    password_hash   VARCHAR(255) NOT NULL
);

-- 4. SALARY STRUCTURES (1:1 Effective Compensation Structure per Employee)
CREATE TABLE salary_structures (
    struct_id           SERIAL PRIMARY KEY,
    emp_id              INT NOT NULL UNIQUE REFERENCES employees(emp_id) ON UPDATE CASCADE ON DELETE CASCADE,
    basic_pay           NUMERIC(12,2) NOT NULL CHECK (basic_pay > 0),
    hra                 NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (hra >= 0),
    special_allowance   NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (special_allowance >= 0),
    pf_contribution     NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (pf_contribution >= 0),
    effective_from      DATE NOT NULL
);

-- 5. LEAVE TYPES (3NF: Leave policy metadata isolated from individual requests)
CREATE TABLE leave_types (
    leave_type_id   SERIAL PRIMARY KEY,
    type_code       VARCHAR(10) NOT NULL UNIQUE,
    type_name       VARCHAR(50) NOT NULL,
    is_paid         BOOLEAN NOT NULL DEFAULT TRUE,
    annual_quota    INT NOT NULL CHECK (annual_quota >= 0)
);

-- 6. LEAVE REQUESTS
CREATE TABLE leave_requests (
    leave_id        SERIAL PRIMARY KEY,
    emp_id          INT NOT NULL REFERENCES employees(emp_id) ON UPDATE CASCADE ON DELETE CASCADE,
    leave_type_id   INT NOT NULL REFERENCES leave_types(leave_type_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    start_date      DATE NOT NULL,
    end_date        DATE NOT NULL,
    total_days      INT NOT NULL CHECK (total_days > 0),
    status          VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED')),
    reason          TEXT,
    applied_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_leave_dates CHECK (end_date >= start_date)
);

-- 7. ATTENDANCE LOGS
CREATE TABLE attendance_logs (
    att_id          SERIAL PRIMARY KEY,
    emp_id          INT NOT NULL REFERENCES employees(emp_id) ON UPDATE CASCADE ON DELETE CASCADE,
    att_date        DATE NOT NULL,
    check_in        TIME,
    check_out       TIME,
    status          VARCHAR(20) NOT NULL CHECK (status IN ('PRESENT', 'LATE', 'HALF_DAY', 'ABSENT', 'ON_LEAVE')),
    late_minutes    INT NOT NULL DEFAULT 0 CHECK (late_minutes >= 0),
    remarks         VARCHAR(255),
    CONSTRAINT uq_emp_att_date UNIQUE (emp_id, att_date),
    CONSTRAINT chk_checkout_after_checkin CHECK (check_out IS NULL OR check_in IS NULL OR check_out >= check_in)
);

-- 8. PAYROLL RUNS (Monthly Processed Payslips - Transactional Ledger)
CREATE TABLE payroll_runs (
    payroll_id          SERIAL PRIMARY KEY,
    emp_id              INT NOT NULL REFERENCES employees(emp_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    pay_month           INT NOT NULL CHECK (pay_month BETWEEN 1 AND 12),
    pay_year            INT NOT NULL CHECK (pay_year >= 2020),
    working_days        INT NOT NULL CHECK (working_days > 0),
    present_days        NUMERIC(4,1) NOT NULL CHECK (present_days >= 0),
    unpaid_leave_days   NUMERIC(4,1) NOT NULL DEFAULT 0 CHECK (unpaid_leave_days >= 0),
    late_penalty_days   NUMERIC(4,1) NOT NULL DEFAULT 0 CHECK (late_penalty_days >= 0),
    gross_earnings      NUMERIC(12,2) NOT NULL CHECK (gross_earnings >= 0),
    tax_deduction       NUMERIC(12,2) NOT NULL CHECK (tax_deduction >= 0),
    pf_deduction        NUMERIC(12,2) NOT NULL CHECK (pf_deduction >= 0),
    lop_deduction       NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (lop_deduction >= 0),
    net_pay             NUMERIC(12,2) NOT NULL CHECK (net_pay >= 0),
    payment_status      VARCHAR(20) NOT NULL DEFAULT 'PROCESSED' CHECK (payment_status IN ('DRAFT', 'PROCESSED', 'PAID')),
    processed_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_emp_pay_period UNIQUE (emp_id, pay_month, pay_year)
);

-- 9. AUDIT LOGS (Security & Transaction Traceability)
CREATE TABLE audit_logs (
    audit_id        SERIAL PRIMARY KEY,
    actor_user      VARCHAR(80) NOT NULL,
    action_type     VARCHAR(40) NOT NULL,
    target_table    VARCHAR(50) NOT NULL,
    target_id       INT,
    details         TEXT,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
