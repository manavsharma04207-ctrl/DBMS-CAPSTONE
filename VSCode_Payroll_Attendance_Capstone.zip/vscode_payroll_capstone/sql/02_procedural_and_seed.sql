-- ============================================================================
-- PHASE 2: PROCEDURAL IMPLEMENTATION & SAMPLE DATASET
-- Includes: Stored Functions, Procedures, Validation Triggers, and Seed Data
-- ============================================================================

SET search_path TO payroll_mgmt;

-- ----------------------------------------------------------------------------
-- 1. STORED FUNCTION: Progressive Monthly TDS / Income Tax Calculation
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_calculate_monthly_tax(p_gross_monthly NUMERIC)
RETURNS NUMERIC(12,2)
LANGUAGE plpgsql
AS $$
DECLARE
    v_annual_gross NUMERIC;
    v_annual_tax   NUMERIC := 0;
BEGIN
    IF p_gross_monthly < 0 THEN
        RAISE EXCEPTION 'Invalid gross salary: % cannot be negative', p_gross_monthly;
    END IF;

    v_annual_gross := p_gross_monthly * 12;

    -- Progressive Tax Slabs (Standardized IT Firm Payroll Regime)
    IF v_annual_gross <= 400000 THEN
        v_annual_tax := 0;
    ELSIF v_annual_gross <= 800000 THEN
        v_annual_tax := (v_annual_gross - 400000) * 0.05;
    ELSIF v_annual_gross <= 1200000 THEN
        v_annual_tax := 20000 + (v_annual_gross - 800000) * 0.10;
    ELSIF v_annual_gross <= 1600000 THEN
        v_annual_tax := 60000 + (v_annual_gross - 1200000) * 0.15;
    ELSE
        v_annual_tax := 120000 + (v_annual_gross - 1600000) * 0.20;
    END IF;

    RETURN ROUND(v_annual_tax / 12.0, 2);
END;
$$;

-- ----------------------------------------------------------------------------
-- 2. STORED PROCEDURE: Monthly Salary Calculation & Payslip Generation
-- Rule: 3 Late Marks = 0.5 Day Loss of Pay (LOP) penalty; Unpaid leaves deducted
-- ----------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE sp_generate_monthly_payroll(
    p_emp_id        INT,
    p_month         INT,
    p_year          INT,
    p_working_days  INT DEFAULT 22
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_basic         NUMERIC(12,2);
    v_hra           NUMERIC(12,2);
    v_special       NUMERIC(12,2);
    v_pf            NUMERIC(12,2);
    v_gross         NUMERIC(12,2);
    v_present_days  NUMERIC(4,1);
    v_late_count    INT;
    v_late_pen_days NUMERIC(4,1);
    v_unpaid_days   NUMERIC(4,1);
    v_per_day_pay   NUMERIC(12,2);
    v_lop_deduction NUMERIC(12,2);
    v_taxable_gross NUMERIC(12,2);
    v_tax           NUMERIC(12,2);
    v_net_pay       NUMERIC(12,2);
BEGIN
    -- Fetch employee salary structure
    SELECT basic_pay, hra, special_allowance, pf_contribution
    INTO v_basic, v_hra, v_special, v_pf
    FROM salary_structures
    WHERE emp_id = p_emp_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Salary structure not configured for emp_id=%', p_emp_id;
    END IF;

    v_gross := v_basic + v_hra + v_special;

    -- Count attendance days (PRESENT + LATE = 1.0, HALF_DAY = 0.5, ON_LEAVE paid = 1.0)
    SELECT COALESCE(SUM(
        CASE
            WHEN status IN ('PRESENT', 'LATE') THEN 1.0
            WHEN status = 'HALF_DAY' THEN 0.5
            ELSE 0.0
        END
    ), 0)
    INTO v_present_days
    FROM attendance_logs
    WHERE emp_id = p_emp_id
      AND EXTRACT(MONTH FROM att_date) = p_month
      AND EXTRACT(YEAR FROM att_date) = p_year;

    -- Count late arrivals
    SELECT COUNT(*)
    INTO v_late_count
    FROM attendance_logs
    WHERE emp_id = p_emp_id
      AND status = 'LATE'
      AND EXTRACT(MONTH FROM att_date) = p_month
      AND EXTRACT(YEAR FROM att_date) = p_year;

    -- Every 3 late marks incurs 0.5 day LOP
    v_late_pen_days := FLOOR(v_late_count / 3) * 0.5;

    -- Calculate unpaid leave days (ABSENT logs or approved LWP leaves)
    SELECT COALESCE(COUNT(*), 0)
    INTO v_unpaid_days
    FROM attendance_logs
    WHERE emp_id = p_emp_id
      AND status = 'ABSENT'
      AND EXTRACT(MONTH FROM att_date) = p_month
      AND EXTRACT(YEAR FROM att_date) = p_year;

    v_per_day_pay   := ROUND(v_gross / p_working_days, 2);
    v_lop_deduction := ROUND((v_unpaid_days + v_late_pen_days) * v_per_day_pay, 2);
    v_taxable_gross := GREATEST(v_gross - v_lop_deduction, 0);
    v_tax           := fn_calculate_monthly_tax(v_taxable_gross);
    v_net_pay       := GREATEST(ROUND(v_taxable_gross - v_tax - v_pf, 2), 0);

    INSERT INTO payroll_runs (
        emp_id, pay_month, pay_year, working_days, present_days,
        unpaid_leave_days, late_penalty_days, gross_earnings,
        tax_deduction, pf_deduction, lop_deduction, net_pay, payment_status
    ) VALUES (
        p_emp_id, p_month, p_year, p_working_days, v_present_days,
        v_unpaid_days, v_late_pen_days, v_gross,
        v_tax, v_pf, v_lop_deduction, v_net_pay, 'PROCESSED'
    )
    ON CONFLICT (emp_id, pay_month, pay_year)
    DO UPDATE SET
        working_days      = EXCLUDED.working_days,
        present_days      = EXCLUDED.present_days,
        unpaid_leave_days = EXCLUDED.unpaid_leave_days,
        late_penalty_days = EXCLUDED.late_penalty_days,
        gross_earnings    = EXCLUDED.gross_earnings,
        tax_deduction     = EXCLUDED.tax_deduction,
        pf_deduction      = EXCLUDED.pf_deduction,
        lop_deduction     = EXCLUDED.lop_deduction,
        net_pay           = EXCLUDED.net_pay,
        processed_at      = CURRENT_TIMESTAMP;
END;
$$;

-- ----------------------------------------------------------------------------
-- 3. TRIGGER 1: Prevent Overlapping Leave Requests for the Same Employee
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_validate_leave_overlap()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM leave_requests lr
        WHERE lr.emp_id = NEW.emp_id
          AND lr.leave_id <> COALESCE(NEW.leave_id, -1)
          AND lr.status IN ('PENDING', 'APPROVED')
          AND daterange(lr.start_date, lr.end_date, '[]') && daterange(NEW.start_date, NEW.end_date, '[]')
    ) THEN
        RAISE EXCEPTION 'Leave overlap error: Employee % already has an active/approved leave between % and %',
            NEW.emp_id, NEW.start_date, NEW.end_date;
    END IF;

    NEW.total_days := (NEW.end_date - NEW.start_date) + 1;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_prevent_leave_overlap
BEFORE INSERT OR UPDATE ON leave_requests
FOR EACH ROW
EXECUTE FUNCTION fn_validate_leave_overlap();

-- ----------------------------------------------------------------------------
-- 4. TRIGGER 2: Validate Attendance vs Approved Leave & Auto-Compute Late Mins
-- Rule: Office shift starts at 09:30:00; grace window up to 09:45:00.
--       Rejects 'PRESENT'/'LATE' attendance on dates with APPROVED leave.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_validate_attendance_entry()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    v_shift_start TIME := '09:30:00';
    v_grace_limit TIME := '09:45:00';
BEGIN
    -- Block work punch-in if employee is on APPROVED leave on att_date
    IF NEW.status IN ('PRESENT', 'LATE', 'HALF_DAY') AND EXISTS (
        SELECT 1
        FROM leave_requests lr
        WHERE lr.emp_id = NEW.emp_id
          AND lr.status = 'APPROVED'
          AND NEW.att_date BETWEEN lr.start_date AND lr.end_date
    ) THEN
        RAISE EXCEPTION 'Attendance conflict: Employee % has an APPROVED leave on %', NEW.emp_id, NEW.att_date;
    END IF;

    -- Auto-compute late minutes and flag LATE status if check_in > 09:45:00
    IF NEW.check_in IS NOT NULL AND NEW.status IN ('PRESENT', 'LATE') THEN
        IF NEW.check_in > v_grace_limit THEN
            NEW.status := 'LATE';
            NEW.late_minutes := EXTRACT(EPOCH FROM (NEW.check_in - v_shift_start))::INT / 60;
        ELSE
            NEW.status := 'PRESENT';
            NEW.late_minutes := 0;
        END IF;
    END IF;

    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_validate_attendance
BEFORE INSERT OR UPDATE ON attendance_logs
FOR EACH ROW
EXECUTE FUNCTION fn_validate_attendance_entry();

-- ----------------------------------------------------------------------------
-- 5. SAMPLE DATA SEEDING (12 Employees across 3 Months: Aug, Sep, Oct 2026)
-- ----------------------------------------------------------------------------
INSERT INTO departments (dept_name, cost_center, location) VALUES
('Engineering & AI', 'CC-ENG-01', 'Gurugram HQ'),
('Cloud & DevOps', 'CC-OPS-02', 'Gurugram HQ'),
('Product & Design', 'CC-PRD-03', 'Bengaluru Hub'),
('Human Resources', 'CC-HRM-04', 'Gurugram HQ');

INSERT INTO designations (title, grade_level, standard_shift_hrs) VALUES
('HR Manager', 'L4', 8.00),
('Senior Software Engineer', 'L4', 8.50),
('AI/ML Engineer', 'L3', 8.50),
('DevOps Specialist', 'L3', 8.50),
('Product Analyst', 'L2', 8.00),
('Junior Backend Developer', 'L1', 8.00);

-- 12 Employees (1 HR_ADMIN + 11 EMPLOYEES)
INSERT INTO employees (emp_code, full_name, email, dept_id, desig_id, join_date, status, system_role, password_hash) VALUES
('EMP001', 'Ananya Verma',      'ananya.verma@techcorp.in',      4, 1, '2023-02-15', 'ACTIVE', 'HR_ADMIN', 'admin123'),
('EMP002', 'Tanish Sharma',     'tanish.sharma@techcorp.in',     1, 3, '2024-06-01', 'ACTIVE', 'EMPLOYEE', 'emp123'),
('EMP003', 'Rohan Malhotra',    'rohan.malhotra@techcorp.in',    1, 2, '2022-11-10', 'ACTIVE', 'EMPLOYEE', 'emp123'),
('EMP004', 'Priya Nair',        'priya.nair@techcorp.in',        2, 4, '2023-08-21', 'ACTIVE', 'EMPLOYEE', 'emp123'),
('EMP005', 'Kabir Mehta',       'kabir.mehta@techcorp.in',       3, 5, '2024-01-15', 'ACTIVE', 'EMPLOYEE', 'emp123'),
('EMP006', 'Sneha Iyer',        'sneha.iyer@techcorp.in',        1, 2, '2022-04-04', 'ACTIVE', 'EMPLOYEE', 'emp123'),
('EMP007', 'Vikramaditya Rao',  'vikram.rao@techcorp.in',        2, 4, '2023-09-12', 'ACTIVE', 'EMPLOYEE', 'emp123'),
('EMP008', 'Meera Krishnan',    'meera.krishnan@techcorp.in',    1, 3, '2024-03-18', 'ACTIVE', 'EMPLOYEE', 'emp123'),
('EMP009', 'Aditya Kulkarni',   'aditya.kulkarni@techcorp.in',   1, 6, '2025-07-01', 'ACTIVE', 'EMPLOYEE', 'emp123'),
('EMP010', 'Neha Gupta',        'neha.gupta@techcorp.in',        3, 5, '2024-05-20', 'ACTIVE', 'EMPLOYEE', 'emp123'),
('EMP011', 'Siddharth Joshi',   'siddharth.joshi@techcorp.in',   2, 6, '2025-07-15', 'ACTIVE', 'EMPLOYEE', 'emp123'),
('EMP012', 'Kavya Deshmukh',    'kavya.deshmukh@techcorp.in',    4, 1, '2023-06-11', 'ACTIVE', 'HR_ADMIN', 'admin123');

INSERT INTO salary_structures (emp_id, basic_pay, hra, special_allowance, pf_contribution, effective_from) VALUES
(1,  65000, 26000, 19000, 3600, '2026-04-01'),
(2,  55000, 22000, 18000, 3200, '2026-04-01'),
(3,  75000, 30000, 25000, 4200, '2026-04-01'),
(4,  58000, 23200, 16800, 3400, '2026-04-01'),
(5,  45000, 18000, 12000, 2600, '2026-04-01'),
(6,  78000, 31200, 25800, 4400, '2026-04-01'),
(7,  60000, 24000, 16000, 3500, '2026-04-01'),
(8,  52000, 20800, 15200, 3000, '2026-04-01'),
(9,  35000, 14000,  9000, 2100, '2026-04-01'),
(10, 46000, 18400, 13600, 2700, '2026-04-01'),
(11, 34000, 13600,  8400, 2000, '2026-04-01'),
(12, 62000, 24800, 18200, 3500, '2026-04-01');

INSERT INTO leave_types (type_code, type_name, is_paid, annual_quota) VALUES
('CL',  'Casual Leave',       TRUE,  12),
('SL',  'Sick Leave',         TRUE,  10),
('PL',  'Privilege Leave',    TRUE,  18),
('LWP', 'Leave Without Pay',  FALSE, 30);

-- Sample Leave Requests
INSERT INTO leave_requests (emp_id, leave_type_id, start_date, end_date, total_days, status, reason) VALUES
(2, 1, '2026-08-14', '2026-08-14', 1, 'APPROVED', 'Personal family errand'),
(3, 2, '2026-09-10', '2026-09-11', 2, 'APPROVED', 'Viral fever recovery'),
(5, 3, '2026-10-05', '2026-10-07', 3, 'APPROVED', 'Planned annual vacation'),
(9, 1, '2026-10-20', '2026-10-21', 2, 'PENDING',  'Festival travel');

-- Generate 3 Months of Weekday Attendance (Aug 2026, Sep 2026, Oct 2026) for all 12 Employees
DO $$
DECLARE
    d DATE;
    e INT;
    v_in TIME;
    v_out TIME;
    v_status VARCHAR(20);
BEGIN
    FOR d IN SELECT generate_series('2026-08-01'::DATE, '2026-10-31'::DATE, '1 day'::INTERVAL)::DATE LOOP
        -- Skip Saturday (6) and Sunday (0)
        IF EXTRACT(DOW FROM d) NOT IN (0, 6) THEN
            FOR e IN 1..12 LOOP
                -- Check if employee has an APPROVED leave on date d
                IF EXISTS (
                    SELECT 1 FROM leave_requests
                    WHERE emp_id = e AND status = 'APPROVED' AND d BETWEEN start_date AND end_date
                ) THEN
                    INSERT INTO attendance_logs (emp_id, att_date, check_in, check_out, status, remarks)
                    VALUES (e, d, NULL, NULL, 'ON_LEAVE', 'Approved Leave');
                -- Simulate occasional unapproved absence for emp 9 & 11
                ELSIF (e = 9 AND d IN ('2026-08-19', '2026-09-22')) OR (e = 11 AND d = '2026-10-14') THEN
                    INSERT INTO attendance_logs (emp_id, att_date, check_in, check_out, status, remarks)
                    VALUES (e, d, NULL, NULL, 'ABSENT', 'Uninformed absence');
                -- Simulate late arrivals for deterministic employees (triggers auto-LATE)
                ELSIF ((e + EXTRACT(DAY FROM d)::INT) % 7 = 0) THEN
                    v_in  := '09:58:00'::TIME + ((e % 4) * INTERVAL '6 minutes');
                    v_out := '18:30:00'::TIME;
                    INSERT INTO attendance_logs (emp_id, att_date, check_in, check_out, status, remarks)
                    VALUES (e, d, v_in, v_out, 'PRESENT', 'Traffic delay');
                ELSE
                    v_in  := '09:18:00'::TIME + ((e % 5) * INTERVAL '4 minutes');
                    v_out := '18:15:00'::TIME;
                    INSERT INTO attendance_logs (emp_id, att_date, check_in, check_out, status, remarks)
                    VALUES (e, d, v_in, v_out, 'PRESENT', 'Regular shift');
                END IF;
            END LOOP;
        END IF;
    END LOOP;
END $$;

-- Run Monthly Payroll Generation across Aug, Sep, Oct 2026 for all 12 Employees
DO $$
DECLARE
    m INT;
    e INT;
    w_days INT;
BEGIN
    FOR m IN 8..10 LOOP
        w_days := CASE m WHEN 8 THEN 21 WHEN 9 THEN 22 WHEN 10 THEN 22 END;
        FOR e IN 1..12 LOOP
            CALL sp_generate_monthly_payroll(e, m, 2026, w_days);
        END LOOP;
    END LOOP;
END $$;
