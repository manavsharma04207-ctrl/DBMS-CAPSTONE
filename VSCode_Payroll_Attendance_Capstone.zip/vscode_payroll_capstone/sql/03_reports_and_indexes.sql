-- ============================================================================
-- PHASE 3: QUERY & REPORT DEVELOPMENT + INDEX OPTIMIZATION
-- ============================================================================

SET search_path TO payroll_mgmt;

-- ----------------------------------------------------------------------------
-- REPORT 1: Monthly Attendance Summary per Employee
-- ----------------------------------------------------------------------------
SELECT
    e.emp_code,
    e.full_name,
    d.dept_name,
    EXTRACT(YEAR FROM a.att_date)::INT  AS year,
    EXTRACT(MONTH FROM a.att_date)::INT AS month,
    COUNT(*) FILTER (WHERE a.status = 'PRESENT')  AS on_time_days,
    COUNT(*) FILTER (WHERE a.status = 'LATE')     AS late_days,
    COUNT(*) FILTER (WHERE a.status = 'HALF_DAY') AS half_days,
    COUNT(*) FILTER (WHERE a.status = 'ON_LEAVE') AS approved_leaves,
    COUNT(*) FILTER (WHERE a.status = 'ABSENT')   AS absent_days,
    COALESCE(SUM(a.late_minutes), 0)              AS total_late_mins
FROM attendance_logs a
JOIN employees e   ON a.emp_id = e.emp_id
JOIN departments d ON e.dept_id = d.dept_id
WHERE EXTRACT(YEAR FROM a.att_date) = 2026
  AND EXTRACT(MONTH FROM a.att_date) = 10
GROUP BY e.emp_code, e.full_name, d.dept_name, year, month
ORDER BY e.emp_code;

-- ----------------------------------------------------------------------------
-- REPORT 2: Detailed Monthly Salary Slip per Employee
-- ----------------------------------------------------------------------------
SELECT
    p.payroll_id,
    e.emp_code,
    e.full_name,
    d.dept_name,
    des.title AS designation,
    p.pay_month,
    p.pay_year,
    s.basic_pay,
    s.hra,
    s.special_allowance,
    p.gross_earnings,
    p.lop_deduction,
    p.pf_deduction,
    p.tax_deduction,
    p.net_pay,
    p.payment_status
FROM payroll_runs p
JOIN employees e         ON p.emp_id = e.emp_id
JOIN departments d       ON e.dept_id = d.dept_id
JOIN designations des    ON e.desig_id = des.desig_id
JOIN salary_structures s ON e.emp_id = s.emp_id
WHERE p.pay_year = 2026 AND p.pay_month = 10
ORDER BY e.emp_code;

-- ----------------------------------------------------------------------------
-- REPORT 3: Late-Marks & Punctuality Escalation Report
-- ----------------------------------------------------------------------------
SELECT
    e.emp_code,
    e.full_name,
    d.dept_name,
    COUNT(*) AS late_occurrences,
    SUM(a.late_minutes) AS cumulative_late_minutes,
    ROUND(AVG(a.late_minutes), 1) AS avg_late_minutes,
    FLOOR(COUNT(*) / 3) * 0.5 AS lop_penalty_days
FROM attendance_logs a
JOIN employees e   ON a.emp_id = e.emp_id
JOIN departments d ON e.dept_id = d.dept_id
WHERE a.status = 'LATE'
  AND a.att_date BETWEEN '2026-10-01' AND '2026-10-31'
GROUP BY e.emp_code, e.full_name, d.dept_name
HAVING COUNT(*) >= 1
ORDER BY late_occurrences DESC, cumulative_late_minutes DESC;

-- ----------------------------------------------------------------------------
-- INDEX OPTIMIZATION & EXECUTION PLAN BENCHMARK (BEFORE vs AFTER)
-- ----------------------------------------------------------------------------
-- Step A: Capture Execution Plan BEFORE creating composite indexes
EXPLAIN ANALYZE
SELECT e.emp_code, e.full_name, COUNT(*) AS late_count, SUM(a.late_minutes)
FROM attendance_logs a
JOIN employees e ON a.emp_id = e.emp_id
WHERE a.status = 'LATE'
  AND a.att_date BETWEEN '2026-10-01' AND '2026-10-31'
GROUP BY e.emp_code, e.full_name;

-- Step B: Create targeted B-Tree composite and covering indexes
CREATE INDEX idx_att_status_date_emp ON attendance_logs (status, att_date, emp_id) INCLUDE (late_minutes);
CREATE INDEX idx_payroll_period_emp  ON payroll_runs (pay_year, pay_month, emp_id);
CREATE INDEX idx_emp_dept_id         ON employees (dept_id);
CREATE INDEX idx_leave_emp_status    ON leave_requests (emp_id, status, start_date, end_date);

-- Step C: Capture Execution Plan AFTER creating indexes (Index-Only Scan on attendance_logs)
EXPLAIN ANALYZE
SELECT e.emp_code, e.full_name, COUNT(*) AS late_count, SUM(a.late_minutes)
FROM attendance_logs a
JOIN employees e ON a.emp_id = e.emp_id
WHERE a.status = 'LATE'
  AND a.att_date BETWEEN '2026-10-01' AND '2026-10-31'
GROUP BY e.emp_code, e.full_name;
