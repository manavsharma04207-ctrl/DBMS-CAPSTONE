-- ============================================================================
-- PHASE 4: SECURITY, RBAC ACCESS CONTROL, TRANSACTIONS & TEST SUITE
-- ============================================================================

SET search_path TO payroll_mgmt;

-- ----------------------------------------------------------------------------
-- 1. ROLE-BASED ACCESS CONTROL (RBAC) & ROW-LEVEL SECURITY (RLS)
-- ----------------------------------------------------------------------------
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'role_hr_admin') THEN
        CREATE ROLE role_hr_admin NOLOGIN;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'role_employee') THEN
        CREATE ROLE role_employee NOLOGIN;
    END IF;
END $$;

GRANT USAGE ON SCHEMA payroll_mgmt TO role_hr_admin, role_employee;

-- HR_ADMIN: Full CRUD access across all tables and sequences
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA payroll_mgmt TO role_hr_admin;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA payroll_mgmt TO role_hr_admin;

-- EMPLOYEE: Strict Read-Only on own attendance, payroll, salary structure, and leave_requests
REVOKE ALL ON ALL TABLES IN SCHEMA payroll_mgmt FROM role_employee;
GRANT SELECT ON employees, departments, designations, salary_structures, attendance_logs, payroll_runs, leave_requests, leave_types TO role_employee;

-- Enable PostgreSQL Row-Level Security (RLS) so database engine itself enforces self-only reads
ALTER TABLE attendance_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE payroll_runs    ENABLE ROW LEVEL SECURITY;
ALTER TABLE salary_structures ENABLE ROW LEVEL SECURITY;

-- Policies controlled via session variable `app.current_emp_id` and `app.current_role`
CREATE POLICY pol_att_hr_all ON attendance_logs
    FOR ALL TO role_hr_admin USING (true) WITH CHECK (true);

CREATE POLICY pol_att_emp_self ON attendance_logs
    FOR SELECT TO role_employee
    USING (emp_id = NULLIF(current_setting('app.current_emp_id', true), '')::INT);

CREATE POLICY pol_pay_hr_all ON payroll_runs
    FOR ALL TO role_hr_admin USING (true) WITH CHECK (true);

CREATE POLICY pol_pay_emp_self ON payroll_runs
    FOR SELECT TO role_employee
    USING (emp_id = NULLIF(current_setting('app.current_emp_id', true), '')::INT);

CREATE POLICY pol_sal_hr_all ON salary_structures
    FOR ALL TO role_hr_admin USING (true) WITH CHECK (true);

CREATE POLICY pol_sal_emp_self ON salary_structures
    FOR SELECT TO role_employee
    USING (emp_id = NULLIF(current_setting('app.current_emp_id', true), '')::INT);

-- ----------------------------------------------------------------------------
-- 2. TRANSACTIONAL SALARY REVISION & PAYROLL RECALCULATION (COMMIT / ROLLBACK)
-- ----------------------------------------------------------------------------
BEGIN;
    UPDATE salary_structures
    SET basic_pay = 60000.00,
        hra = 24000.00
    WHERE emp_id = 2;

    CALL sp_generate_monthly_payroll(2, 10, 2026, 22);

    INSERT INTO audit_logs (actor_user, action_type, target_table, target_id, details)
    VALUES ('EMP001', 'SALARY_UPDATE_AND_RECALC', 'salary_structures', 2, 'Updated basic_pay to 60000 and recalculated Oct 2026 payroll');
COMMIT;

-- ----------------------------------------------------------------------------
-- 3. AUTOMATED VERIFICATION TEST SUITE (VALID, INVALID & BOUNDARY CASES)
-- ----------------------------------------------------------------------------
-- TEST CASE 1 (VALID): Valid attendance punch-in -> succeeds & computes late_minutes=0
-- TEST CASE 2 (INVALID - NEGATIVE SALARY): Attempting negative basic_pay -> CHECK constraint violation & ROLLBACK
-- TEST CASE 3 (INVALID - DUPLICATE ATTENDANCE): Duplicate (emp_id, att_date) -> UNIQUE constraint violation
-- TEST CASE 4 (INVALID - OVERLAPPING LEAVE): Leave intersecting existing approved leave -> Trigger exception
-- TEST CASE 5 (INVALID - ATTENDANCE ON APPROVED LEAVE): Punch-in during approved leave -> Trigger exception
-- TEST CASE 6 (SECURITY - UNAUTHORIZED UPDATE BY EMPLOYEE): role_employee attempts UPDATE on payroll_runs -> Permission Denied
-- TEST CASE 7 (BOUNDARY - ZERO SALARY / HIGH LOP): High LOP caps net_pay safely at 0.00 without negative underflow
